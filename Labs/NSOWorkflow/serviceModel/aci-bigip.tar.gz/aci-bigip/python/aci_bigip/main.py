# -*- mode: python; python-indent: 4 -*-
import ncs, _ncs
from ncs.application import Service
from ncs.dp import Action


# ----------------
# SERVICE CALLBACK
# ----------------
class ServiceCallbacks(Service):

    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.debug('Service create(service=', service._path, ')')

        vars = ncs.template.Variables()

        # Example of how to add attributes to the vars list.
        # The attribute can be used as {$DUMMY} in the template XML file.
        vars.add('DUMMY', '127.0.0.1')
        vars.add('COMMUNITY', 'private')

        template = ncs.template.Template(service)
        template.apply('aci-template', vars)
        template.apply('bigip-template', vars)


class ProfileCompletionCallbacks(Action):
    def cb_completion(self, uinfo, cli_style,
                      token, completion_char,
                      kp, cmdpath, cmdparam_id, simpleType, extra):
        self.log.info('completion cb called for kp=%s' %kp)

        with ncs.maapi.Maapi() as m:
            with ncs.maapi.Session(m, 'admin', 'system'):
                with m.start_read_trans() as t:
                    service_kp = kp[1:]
                    # service = ncs.maagic.get_node(t, service_kp)
                    root = ncs.maagic.get_root(t)
                    profile_list = list(root.ncs__devices.ncs__device['bigip_phy'].ncs__config.bigip__ltm.bigip__profile)
                    profiles = []
                    for profile in profile_list:
                        profiles.append(profile[6:])

                    #profiles = [profile.name for profile in list(iter(root.ncs__devices.ncs__device['bigip_phy'].ncs__config.
                    #    bigip__ltm.big_ip.profile))]

        values = [(_ncs.dp.COMPLETION_DESC, "Possible completions:", "")]
        values += [(_ncs.dp.COMPLETION, profile, "") for profile in profiles]
        _ncs.dp.action_reply_completion(uinfo, values)



# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        self.log.debug('Main RUNNING')
        self.register_service('aci-bigip-servicepoint', ServiceCallbacks)
        self.register_action('profile-completion', ProfileCompletionCallbacks)

    def teardown(self):
        self.log.debug('Main FINISHED')
